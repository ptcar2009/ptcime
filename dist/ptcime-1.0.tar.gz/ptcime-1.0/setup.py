import setuptools
setuptools.setup(
    name='ptcime',
    version='1.0',
    scripts=['./scripts/ptcime'],
    author='Me',
    description='Little time tracking tool',
    packages=['time_tracking'],
    install_requires=[
    ],
    python_requires='>=3.7'
)
